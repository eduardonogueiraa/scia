<!DOCTYPE html>
<html>
<head>
	<title>Post</title>
</head>
<body>

	<form method="POST" action="<?php echo e(route('postagem.salvar')); ?>">
		<?php echo e(csrf_field()); ?>


		<label>Tema</label>
		<input type="text" name="tema">
		<br>
		<label> Disciplina </label>
			<select name="id_disciplina">
			<?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($disciplina['id']); ?>">
					<?php echo e($disciplina['nome']); ?>

				</option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<br>
		<label>Descrição</label>
		<input type="text" name="descricao">
		
		<br>
		<button type="submit">Enviar</button>
	</form>

</body>
</html>