<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center><h1>Abrir Informação</h1></center>
	Página pra ver informação completa
</body>
</html>