<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center> <h1>SCIA</h1> 
	
	Login <input type="text" name="login"> <br>
	Senha <input type="password" name="senha"> <br>
	<input type="button" value = "Entrar"> <br>
	<a href="{{ url('cadastro') }}">Cadastre-se agora</a> 
	</center>
</body>
</html>