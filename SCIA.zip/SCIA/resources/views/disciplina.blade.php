<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	 <center>Conteúdo</center>
	 Aqui vai ter a listagem de todos os conteúdos da disciplina selecionada
</body>
</html>