<!DOCTYPE html>
<html>
<head>
	<title>Cadastrar Usuário</title>
</head>
<body>
	<center><h1>Cadastrar Usuário</h1>
	
	Nome <input type="text" name="nome"> <br>
	E-mail <input type="email" name="email"> <br>
	Senha <input type="password" name="senha"> <br>
	<input type="button" value="Cadastrar"> 
	</center>
</body>
</html>