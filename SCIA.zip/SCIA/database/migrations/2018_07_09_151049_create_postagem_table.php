<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePostagemTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('postagem', function (Blueprint $table) {
            $table->increments('id');
            $table->text('descricao'); 
            $table->integer('id_usuario')->unsigned(); 
            $table->foreign('id_usuario')->references('id_usuario')->on('usuario'); 
            $table->integer('id_disc')->unsigned(); 
            $table->foreign('id_disc')->references('id_disc')->on('disciplina'); 
            $table->integer('id_tema')->unsigned(); 
            $table->foreign('id_tema')->references('id_tema')->on('tema'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('postagem');
    }
}
