<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function login (){
    	return view('login'); 
    }

    public function cadastro(){
    	return view('cadastro'); 
    }

    public function inicial (){
    	return view('inicial'); 
    }

    public function disciplina (){
    	return view('disciplina'); 

    }

    public function abririnformacao(){
    	return view('abririnformacao'); 
    }
}

