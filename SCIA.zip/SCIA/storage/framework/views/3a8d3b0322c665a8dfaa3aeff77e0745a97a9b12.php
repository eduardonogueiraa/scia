<!DOCTYPE html>
<html>
<head>
	<title>Página Inicial</title>
</head>
<body>
	<form method="POST" action='/disciplina'>
		<?php echo e(csrf_field()); ?>

		
		<center><h1>Página Inicial</h1></center>
		<select id="disciplina">
    		<option value="" >Selecione a disciplina </option>
    		<option value="redes" >Redes</option>
   	 		<option value="manut" >Manutenção</option>
			<option value="bd" >Banco de Dados</option>
			<option value="aw" >Autoria Web</option>
			<option value="so" >Sistemas Operacionais</option>
			<option value="ppi" >Programação para Internet</option>
			<option value="pds" >Projeto de Desenv de Software</option>
		</select>
	<input type="submit" value="Ok">
	</form>
</body>

</html>