<!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <title>Teste</title>
  </head>

 <body>
     <header>
         <h1>Meu blog</h1>
     </header>
         <ul>
             <li><a href="#"/>Home</a></li>
             <li><a href="#"/>Banco de Dados</a></li>
             <li><a href="#"/>Programação</a></li>
         </ul>

    	<?php echo $__env->yieldContent('conteudo'); ?>

	</body>
</html>