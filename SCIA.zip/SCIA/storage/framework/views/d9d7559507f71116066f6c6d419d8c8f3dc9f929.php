<?php $__env->startSection('conteudo'); ?>
<h2>Título </h2>
<p> TESTE 1,2,3 </p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>